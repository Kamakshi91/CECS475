﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Input;

using simplecal.Command;

namespace simplecal.ViewModel
{
    public class ViewModel: INotifyPropertyChanged
    {
        public ICommand com { get; set; }
        public string sum { get { return "+"; } set { } }
        public string sub { get { return "-"; } set { } }
        public string mul { get { return "*"; } set { } }
        public string div { get { return "/"; } set { } }
      
        public event PropertyChangedEventHandler PropertyChanged;


        private void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
        private bool flag=true;
        public bool Flag
        {
            get { return flag; }
            set
            {
                if (Number1 != null || Number1 != null)
                {
                    if (Number2 != "0" || Number2 != "0")
                    {
                        flag = true;

                    }
                    else
                    {
                        flag = false;
                    }

                }
                else
                {
                    flag = false;
                }
                OnPropertyChanged("Number1");
                OnPropertyChanged("Number2");
            }
        }

        private string _number1;
        public string Number1
        {
            get { return _number1; }
            set { _number1 = value; OnPropertyChanged("Number1"); }
        }


        private string _number2;
        public string Number2
        {
            get { return _number2; }
            set { _number2 = value; OnPropertyChanged("Number2"); }
        }


        private string _result;


        public string Result
        {
            get { return _result; }
            set { _result = value; OnPropertyChanged("Result"); }
        }

        public ViewModel()
        {
       

            com = new NewCommand(execute, canexecute);
            

        }
        

        private bool canexecute(object parameter)
        {
            if (Number1 != null || Number2 != null)
            {
                return true;

            }
            else { return false; }
        }

        private void execute(object parameter)
        {
            if (Number1 == null || Number2== null || Number2=="0" || Number1 == "0")
            {
                flag= false;

            }
            switch (parameter)
            {
                case "+":
                    Result = (Convert.ToDouble(Number1) + Convert.ToDouble(Number2)).ToString();
                    break;
                case "-":
                    Result = (Convert.ToDouble(Number1) - Convert.ToDouble(Number2)).ToString();
                    break;
                case "*":
                    Result = (Convert.ToDouble(Number1) * Convert.ToDouble(Number2)).ToString();
                    break;
                case "/":
                    Result = (Convert.ToDouble(Number1) / Convert.ToDouble(Number2)).ToString();
                    break;
            }
            
        }
        
    
    }
}
