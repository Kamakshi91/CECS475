﻿using System;

using System.Windows.Input;

namespace simplecal.Command
{
    class NewCommand : ICommand
    {

        Action<object> _execute;
            //_sum,_sub,_mul,_div;
        Func<object, bool> _canexecute;
        public NewCommand(Action<object> execute, Func<object, bool> canexecute)
        {
            _execute = execute;
            _canexecute = canexecute;

        }
        public bool CanExecute(object parameter)
        {
            if (_canexecute != null)
            {
                return _canexecute(parameter);
            }
            else
            {
                return false;
            }
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }
        

    }
}
