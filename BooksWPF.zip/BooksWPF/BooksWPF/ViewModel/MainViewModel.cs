using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Windows.Input;
using System.Linq;

namespace BooksWPF.ViewModel
{
    /// <summary>
    /// This class contains properties that the main View can data bind to.
    /// <para>
    /// Use the <strong>mvvminpc</strong> snippet to add bindable properties to this ViewModel.
    /// </para>
    /// <para>
    /// You can also use Blend to data bind with the tool's support.
    /// </para>
    /// <para>
    /// See http://www.galasoft.ch/mvvm
    /// </para>
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        /// 
        //Icomand to call all the queries
        
        string textArea;
        public string TextArea
        {
            get { return textArea; }
            set
            {
                textArea = value;
                RaisePropertyChanged("TextArea");
            }
        }
        public MainViewModel()
        {
            QueryCommandMethod();
        }
        public void QueryCommandMethod()
        {
            BooksEntities db = new BooksEntities();

            //A
            // get all the titles and the authors who wrote them. 
            // Sort the result by title.
            var AuthorAndTitlesA =

               from author in db.Authors
               from book in author.Titles
               orderby book.Title1
               select new
               {
                   book.Title1,
                   author.FirstName,
                   author.LastName
               };

            TextArea += ("A: Titles and Authors : ");

            // display authors and Titles 
            foreach (var element in AuthorAndTitlesA)
            {
                TextArea += (String.Format("\r\n\t{0} :   {1} {2}",
                       element.Title1, element.FirstName, element.LastName));
            }


            //B

            // all the titles and the authors who wrote them.
            //Sort the result by title. 
            //For each title sort the authors alphabetically by last name, then first name.
            var authorsAndTitlesB =
               (from book in db.Titles
                from author in book.Authors
                orderby book.Title1, author.LastName, author.FirstName
                select new
                {
                    book.Title1,
                    author.FirstName,
                    author.LastName,

                });

            TextArea += "\r\n\r\nB: Authors and titles with authors sorted for each title :";

            //display
            foreach (var element in authorsAndTitlesB)
            {
                TextArea += (
                   String.Format("\r\n\t{0} :   {1} {2}",
                     element.Title1, element.FirstName, element.LastName));
            }

            //C
            // get authors and titles of each book 
            // grouped by title, last name, first name for each book title
            var titlesByAuthor =
               from author in db.Titles
               orderby author.Title1
               select new
               {
                   BookTitles = author.Title1 ,
                   AuthorNames =
                     from book in author.Authors
                     orderby book.LastName, book.FirstName
                     select new { book.FirstName, book.LastName }
               };

            TextArea += "\r\n\r\nC: Titles grouped by author:";

            // display in order titles written by each author, grouped by author
            foreach (var title1 in titlesByAuthor)
            {
                // display book Title's name
                TextArea += ("\r\n\t" + title1.BookTitles + ":");

                // display  authors for that book
                foreach (var book1 in title1.AuthorNames)
                {
                    TextArea += ("\r\n\t\t" + book1.FirstName + " " + book1.LastName);
                }
            }

            TextArea = TextArea;
            Console.WriteLine(TextArea);
        }
    }
}