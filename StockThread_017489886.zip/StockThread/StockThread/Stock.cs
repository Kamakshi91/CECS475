﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace StockThread
{
    public class Stock
    {
        public Stock()
        {
        }

        
        public delegate void stockDele(string name, int currval, int nochanges);
        public EventHandler StockHand;
        public event stockDele StockEvent;
        private string name;
        private int initialValue;
        private int maxChange;
        private int Notifythreshold;

        private int noOfchanges;
        private int currentValue;
        Thread StockThread;
        public Stock(string name, int startval, int maxchange, int threshold)
        {
            this.name = name;
            initialValue = startval;
            currentValue = initialValue;
            maxChange = maxchange;
            Notifythreshold = threshold;
            StockThread= new Thread(new ThreadStart(Activate));
            StockThread.Start();
        }
        public string getcurrentvalue()
        {
            return currentValue.ToString();
        }
        public string getchanges()
        {
            return noOfchanges.ToString();
        }
        public string getname()
        {
            return name;
        }
        public void Activate()
        {

            for (int i = 0; i <= 60; i++)
            {
                //sleep thread for 1 1/2 a second.
                Thread.Sleep(500);
                //call function to change stocks value.
                ChangeStockValue();
                if(StockHand!= null)
                {
                    StockHand(this, null);
                }
            }

        }

        private void ChangeStockValue()
        {      // Random the stock value
            Random RandValue = new Random();
            currentValue += RandValue.Next(0, maxChange);
            noOfchanges++;
               //Check the threshold
               if((currentValue - initialValue)> Notifythreshold)
                {
                if (StockEvent != null)
                {
                    StockEvent(name, currentValue, noOfchanges);
                }
            }
               //Greater than Threshold then raise the event

        }

        
    }


}
