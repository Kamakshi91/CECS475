﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;

namespace StockThread
{
    class StockBroker
    {
        List<Stock> stockList = new List<Stock>();
        string Brokername;
        // creates object we will use to lock the output
        //Create a file object to write data to the file
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        public static ReaderWriterLockSlim LockEvent = new ReaderWriterLockSlim();
        DateTime now = DateTime.Now;
        
    public StockBroker(string name)
        {
            Brokername = name;
            
        }
       
        

        
        //The function AddStock should subscribe the event.
        public void AddStock(Stock stock)
        {
            stockList.Add(stock);
            stock.StockHand += OnEvent;

        }
        protected void OnEvent(Object outp, EventArgs e)
        {
            LockEvent.EnterWriteLock();
            Stock newS = (Stock)outp;
            string dispchanges =newS.getchanges();
            string dispname=newS.getname();
            string dispcurrentvalue=newS.getcurrentvalue();
            
            Console.WriteLine(Brokername.PadRight(20)  + dispname.PadRight(20)  + dispcurrentvalue.PadRight(20)+dispchanges);
            using (StreamWriter outputfile = new StreamWriter(path + @"\StockFile.txt", true))
            {
             outputfile.WriteLine(now.ToString().PadRight(30)+Brokername.PadRight(20)+dispname.PadRight(20)+dispcurrentvalue.PadRight(20) + dispchanges);
            }
            LockEvent.ExitWriteLock();
        }



    }
}
