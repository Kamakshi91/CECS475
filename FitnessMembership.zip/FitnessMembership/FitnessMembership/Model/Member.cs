﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessMembership.Model
{
   public class Member : ObservableObject
    {         /// <summary>   
        /// The member's first name.    
        /// /// </summary>       
        private string firstName;

        /// <summary>        
        /// /// The member's last name. 
        /// /// </summary>  
        private string lastName;
        public Member() { } 

        /// <summary>        
        /// /// Creates a new member.
        /// /// </summary>         ///
        //<param name="fName">The member's first name.</param>       
        /// <param name="lName">The member's last name.</param>        
        /// /// <param name="mail">The member's e-mail.</param>       
        public Member(string fName, string lName, string mail)
        {
            this.firstName = fName;
            this.lastName = lName;
            this.email = mail;
        } 


        public string FirtName
        {
            get { return firstName; }
            set
            {
                firstName = value;
            }
        }
        /// <summary>        
        /// /// A property that gets or sets the member's last name, and makes sure it's not too long.    
        /// /// </summary>        
        /// /// <returns>The member's last name.</returns>       
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                if (value.Length > 25)
                {
                    throw new ArgumentException("Too long");
                }

                if (value.Length == 0)
                {
                    throw new NullReferenceException();
                }

                lastName = value;
            }
        }
        private string email;
        /// <summary>       
        /// /// A property that gets or sets the member's e-mail, and makes sure it's not too long.        
        /// /// </summary>       
        /// /// <returns>The member's e-mail.</returns>     
        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                if (value.Length > 30)
                {
                    throw new ArgumentException("Too long");
                } 
 
                if (value.Length == 0)
                {
                    throw new NullReferenceException();

                } 
 
                if (value.IndexOf("@") == -1 || value.IndexOf(".") == -1)
                {
                    throw new FormatException();

                }

                email = value;
            }
        } 
 
        /// <summary>      
        /// /// Text to be displayed in the list box.  
        /// /// </summary>       
        /// /// <returns>A concatenation of the member's first name, last name, and email.</returns>   


    }
}
