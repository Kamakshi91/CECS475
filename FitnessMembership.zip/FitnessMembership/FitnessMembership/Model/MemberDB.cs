﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using System.Collections.ObjectModel;
using System.IO;



namespace FitnessMembership.Model
{

    /// <summary>
    /// A class that uses a text file to store information about the gym members long-term.
    /// </summary>
    class MemberDB : ObservableObject
    {
        /// <summary>
        /// The list of members to be saved.
        /// </summary>
        private ObservableCollection<Member> members;
        /// <summary>
        /// Where the database is stored.
        /// </summary>
        private const string filepath = "../members.txt";

        /// <summary>
        /// Creates a new member database.
        /// </summary>
        /// <param name="m">The list to saved from or written to.</param>
        public MemberDB(ObservableCollection<Member> m)
        {
            members = m;
        }

        /// <summary>
        /// Reads the saved text file database into the program's list of members.
        /// </summary>
        /// <returns>The list containing the text file data read in.</returns>
        public ObservableCollection<Member> GetMemberships()
        {
            try
            {
                StreamReader input = new StreamReader(new FileStream(filepath, FileMode.OpenOrCreate, FileAccess.Read));

                string[] separatingChar = { "|" };
                // Creates a new StreamReader whenever opened.
                // Closes the file after finishing.
                using (StreamReader sr = new StreamReader("memebers.txt"))
                {
                    //Checking the end of the file
                    while (sr.Peek() != -1)
                    {
                        var line = sr.ReadLine();
                        // Detecting each delimeter, removing each delimeter, and adding
                        // each string between the delimeter as objects in the indexer.
                        string[] info = line.Split(separatingChar, System.StringSplitOptions.RemoveEmptyEntries);
                        members.Add(new Member(info[0], info[1], info[2]));
                    }
                }
                input.Close();
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File not found");
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid e-mail address format.");
            }
            return members;
        }

        /// <summary>
        /// Saves the program's list of members into the text file database.
        /// </summary>
        public void SaveMemberships()
        {
            StreamWriter output = new StreamWriter(new FileStream(filepath, FileMode.Create, FileAccess.Write));
            using (StreamWriter sm = new StreamWriter("memebers.txt"))
            {
                // Each member's properties are added in-line in the file.
                foreach (Member m in members)
                {
                   
                    sm.Write(m.FirtName + "|");
                    sm.Write(m.LastName + "|");
                    sm.Write(m.Email + "|");
                    sm.WriteLine();
                    
                }
            }


            output.Close();
        }

    }
}
