﻿using BusinessLayer;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    public class Program
    {


        static void Main(string[] args)
        {
            int id;
            bool end = false;
            string name, option;
            BusinessLayer.BusinessLayer bL = new BusinessLayer.BusinessLayer();

            IEnumerable<Teacher> teach ;
            IEnumerable<Course> courses;

            Teacher teacher;
            Course course;

            while (!end)
            {
                Console.WriteLine("Choose from below to perform CRUD on following:");
                Console.WriteLine("1.  Table Teacher\n" +
                                    "2. Table Course\n" +
                                    "3. Exit Program");
                string strInput = Console.ReadLine();

                int intTemp = 0;
                if (int.TryParse(strInput, out intTemp))
                {
                    intTemp = Convert.ToInt32(strInput);
                }
                if (intTemp == 1)
                {
                    bool teacherEnd = false;

                    while (!teacherEnd)
                    {
                        Console.Write("Kindly choose your selection of CRUD on Teacher table: ");
                        Console.WriteLine("Teacher Table Options:\n" +
                                            "1. Create Teacher\n" +
                                            "2. Update Teacher\n" +
                                            "3. Delete Teacher\n" +
                                            "4. Display all Teacher\n" +
                                            "5. Display all courses taught by an individual teacher\n" +
                                            "6. Exit menu.");

                        int input = Convert.ToInt32(Console.ReadLine());
                        switch (input)
                        {
                            case 1:
                                Console.WriteLine("Please enter the teacher name.");
                                Console.Write("Name: ");
                                name = Console.ReadLine();


                                teacher = new Teacher
                                {
                                    TeacherName = name,

                                };


                                bL.AddTeacher(teacher);
                                break;
                            case 2:
                                Console.Write("Would you like to update by teacher name or teacher id?: ");
                                option = Console.ReadLine();
                                Console.WriteLine();
                                if (option.Equals("name"))
                                {
                                    Console.Write("Enter the teacher name you are searching for: ");
                                    name = Console.ReadLine();
                                    teacher = bL.GetTeacherByName(name);
                                    teacher = bL.GetTeacherByID(teacher.TeacherId);
                                    Console.Write("\nEnter the updated teacher name: ");
                                    teacher.TeacherName = Console.ReadLine();
                                    bL.UpdateTeacher(teacher);
                                }
                                else if (option.Equals("id"))
                                {
                                    Console.Write("Enter the teacher ID you are searching for: ");
                                    id = Convert.ToInt16(Console.ReadLine());
                                    teacher = bL.GetTeacherByID(id);
                                    Console.WriteLine();
                                    Console.Write("Enter the updated teacher name: ");
                                    teacher.TeacherName = Console.ReadLine();
                                    bL.UpdateTeacher(teacher);
                                }
                                break;
                            case 3:
                                Console.Write("Enter the teacher ID you want to delete: ");
                                id = Convert.ToInt16(Console.ReadLine());
                                teacher = bL.GetTeacherByID(id);
                                bL.RemoveTeacher(teacher);
                                break;
                            case 4:
                                teach = bL.GetAllTeachers();
                                Console.WriteLine();
                                foreach (Teacher teacherloop in teach)
                                {
                                    Console.WriteLine(teacherloop.TeacherName + " " + teacherloop.TeacherId);
                                }
                                Console.WriteLine();
                                break;
                            case 5:
                                courses = bL.GetAllCourses();
                                Console.Write("Enter the teacher ID you wish to access: ");
                                id = Convert.ToInt16(Console.ReadLine());
                                teacher = bL.GetTeacherByID(id);
                                Console.WriteLine("\nCourses taught by " + teacher.TeacherName + ": ");
                                Console.WriteLine("\nCourses: " + "\t\t" + "Course ID:");
                                foreach (Course c in courses)
                                {
                                    if (c.TeacherId == id)
                                    {
                                        Console.WriteLine(c.CourseName + "\t\t\t" + c.CourseId);
                                    }

                                }
                                Console.WriteLine();
                                break;
                            default:
                                teacherEnd = true;
                                break;
                        }
                    }

                }
                else if(intTemp==2)
                {
                    bool courseEnd = false;

                    while (!courseEnd)
                    {
                        Console.Write("Kindly choose your selection of CRUD on Course table: ");
                        Console.WriteLine("Teacher Table Options:\n" +
                                            "1. Create Course\n" +
                                            "2. Update Course\n" +
                                            "3. Delete Course\n" +
                                            "4. Display all Courses\n" +      
                                            "5. Exit menu.");

                        int input = Convert.ToInt32(Console.ReadLine());
                        switch (input)
                        {
                            case 1:
                                Console.WriteLine("Please enter the course name.");
                                Console.Write("Name: ");
                                name = Console.ReadLine();

                                Console.Write("New course teacher's ID: ");
                                id = Convert.ToInt16(Console.ReadLine());

                                course = new Course
                                {
                                    CourseName = name,
                                    TeacherId = id
                                };

                                bL.AddCourse(course);
                                break;
                            case 2:
                                Console.Write("Would you like to update by course name or course id?: ");
                                option = Console.ReadLine();
                                Console.WriteLine();
                                if (option.Equals("name"))
                                {
                                    Console.Write("Enter the course name you are searching for: ");
                                    name = Console.ReadLine();
                                    course = bL.GetCourseByName(name);
                                    course = bL.GetCourseByID(course.CourseId);
                                    Console.Write("\nEnter the updated course name: ");
                                    course.CourseName = Console.ReadLine();
                                    bL.UpdateCourse(course);
                                }
                                else if (option.Equals("id"))
                                {
                                    Console.Write("Enter the course ID you are searching for: ");
                                    id = Convert.ToInt16(Console.ReadLine());
                                    course = bL.GetCourseByID(id);
                                    Console.Write("\nEnter the updated course name: ");
                                    course.CourseName = Console.ReadLine();
                                    bL.UpdateCourse(course);
                                }
                                break;
                          
                            case 3:
                                Console.Write("Enter the course ID you want to delete: ");
                                id = Convert.ToInt16(Console.ReadLine());
                                course = bL.GetCourseByID(id);

                                //Get rid of all connections in course
                                if (course.TeacherId != null)
                                {
                                    teacher = bL.GetTeacherByID((int)course.TeacherId);
                                    teacher.Courses.Remove(course);
                                    bL.UpdateTeacher(teacher);
                                }

                                course.Teacher = null;
                                course.Students.Clear();
                                bL.UpdateCourse(course);

                                bL.RemoveCourser(course);
                                break;
                            case 4:
                                courses = bL.GetAllCourses();
                                Console.WriteLine();
                                foreach (Course courseLoop in courses)
                                {
                                    Console.WriteLine(courseLoop.CourseName + " " + courseLoop.CourseId);
                                }
                                Console.WriteLine();
                                break;
                            default:
                                courseEnd = true;
                                break;
                        }
                    }

                }

                else if (intTemp == 3)
                {
                    Console.WriteLine("Program has been exited!! Bye Bye");
                    end = true;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please select one of the above options.\n");
                }

            }

        }

    }

       
    
}
